

import React, { useState } from "react";
import { View, Text, Pressable, StyleSheet, ScrollView } from "react-native";
import { FontAwesome } from "@expo/vector-icons";

const GerenciamentoCursos = ({ navigation, route }) => {
  const [visibilidadeMenu, setVisibilidadeMenu] = useState(false);

  const handleMenu = () => {
    setVisibilidadeMenu(!visibilidadeMenu);
  };

  return (
    <View style={styles.container}>
      <View style={styles.topo}>
        <Pressable style={{ marginLeft: 20 }} onPress={handleMenu}>
          <FontAwesome name="bars" size={30} />
        </Pressable>
        <Text style={{ color: "white", marginLeft: 400, fontSize: 30 }}>
          Gerenciamento de Cursos
        </Text>
      </View>
      <View style={styles.viewMae}>
        <View style={styles.quadroEsquerda}>
          <View style={styles.viewTopoSeparacao}>
            <Text style={styles.txtTopoSeparacao}>Lista de Cursos</Text>
          </View>
          <ScrollView style={styles.listaDeCursos}></ScrollView>
          <View style={styles.viewAddCurso}>
            <Pressable style={styles.btnAddCurso}>
              <Text style={{ fontSize: 20, padding: 15, fontWeight: "bold" }}>
                Adicionar Curso
              </Text>
            </Pressable>
          </View>
        </View>
        <View style={styles.quadroDireita}>
          <View style={styles.viewTopoSeparacao}>
            <Text style={{ ...styles.txtTopoSeparacao, fontWeight: "bold" }}>
              Informações
            </Text>
          </View>
          <View style={styles.viewInformacoes}>
            <Text style={{ ...styles.txtInformacoes, borderTopWidth: 0 }}>
              Nome do Curso: {/* curso.nome_curso */}
            </Text>
            <Text style={styles.txtInformacoes}>
              Carga Horária: {/* curso.carga_horaria */}
            </Text>
            <Text style={styles.txtInformacoes}>
              Nível: {/* curso.nivel */}
            </Text>
          </View>
          <View style={styles.viewListaTurmas}>
            <Text style={{ ...styles.txtTopoSeparacao, fontWeight: "bold" }}>
              Lista de Turmas
            </Text>
          </View>

          <View style={{ flexDirection: "row", height: "9%" }}>
            <View style={styles.viewSiglaTopo}>
              <Text style={styles.txtMedioCentralizado}>Sigla da Turma</Text>
            </View>
            <View style={styles.viewOperacaoTopo}>
              <Text style={styles.txtMedioCentralizado}>Operação</Text>
            </View>
          </View>

          <View style={{ flexDirection: "row", height: "100%" }}>
            <ScrollView style={{ width: "70%", borderRightWidth: 2 }}>
              <Text
                style={{
                  ...styles.txtMedioCentralizado,
                  borderBottomWidth: 2,
                  padding: 5,
                }}
              >
                Teste
              </Text>
              <Text
                style={{
                  ...styles.txtMedioCentralizado,
                  borderBottomWidth: 2,
                  padding: 5,
                }}
              >
                Teste
              </Text>
            </ScrollView>
            <ScrollView style={{ width: "30%" }}>
              <FontAwesome
                name="times"
                size={24}
                color="red"
                style={{
                  textAlign: "center",
                  borderBottomWidth: 2,
                  padding: 5,
                }}
              />
              <FontAwesome
                name="check"
                size={24}
                color="green"
                style={{
                  textAlign: "center",
                  borderBottomWidth: 2,
                  padding: 5,
                }}
              />
            </ScrollView>
          </View>
        </View>
      </View>

      {visibilidadeMenu && (
        <View style={styles.menu}>
          <View style={styles.cabecalhoMenu}>
            <Text
              style={{ fontSize: 40, color: "white", marginHorizontal: 60 }}
            >
              MasterNote
            </Text>
            <Pressable onPress={handleMenu}>
              <FontAwesome name="bars" size={50} />
            </Pressable>
          </View>
          <View
            style={{
              height: "82%",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <Pressable
              style={{
                ...styles.menuBotoes,
                marginTop: 20,
                backgroundColor: "gray",
              }}
            >
              <Text style={{ fontSize: 18 }}>Gerenciar</Text>
              <Text>Curso</Text>
            </Pressable>
            <Pressable style={styles.menuBotoes}>
              <Text style={{ fontSize: 18 }}>Gerenciar</Text>
              <Text>Turma</Text>
            </Pressable>
            <Pressable style={styles.menuBotoes}>
              <Text style={{ fontSize: 18 }}>Gerenciar</Text>
              <Text>Unidade Curricular</Text>
            </Pressable>
            <Pressable style={styles.menuBotoes}>
              <Text style={{ fontSize: 18 }}>Gerenciar</Text>
              <Text>Situação de Aprendizagem</Text>
            </Pressable>
            <Pressable style={styles.menuBotoes}>
              <Text style={{ fontSize: 18 }}>Gerenciar</Text>
              <Text>Avaliações</Text>
            </Pressable>
            <Pressable style={styles.menuBotoes}>
              <Text style={{ fontSize: 18 }}>Relatório de</Text>
              <Text>Desempenho</Text>
            </Pressable>
          </View>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  topo: {
    height: "8%",
    flexDirection: "row",
    backgroundColor: "blue",
    alignItems: "center",
  },
  viewMae: {
    flexDirection: "row",
    height: "92%",
  },
  quadroEsquerda: {
    width: "28%",
    borderWidth: 2,
  },
  quadroDireita: {
    width: "72%",
    borderWidth: 2,
  },
  viewTopoSeparacao: {
    height: "6%",
    borderBottomWidth: 2,
    justifyContent: "center",
  },
  txtTopoSeparacao: {
    textAlign: "center",
    color: "red",
    fontSize: 20,
  },
  listaDeCursos: {
    borderBottomWidth: 2,
  },
  viewAddCurso: {
    height: "14%",
    justifyContent: "center",
    alignItems: "center",
  },
  btnAddCurso: {
    width: "95%",
    backgroundColor: "yellow",
    justifyContent: "center",
    borderWidth: 2,
    borderRadius: 20,
    alignItems: "center",
  },
  viewInformacoes: {
    height: "18%",
    borderBottomWidth: 2,
    justifyContent: "center",
  },
  txtInformacoes: {
    fontSize: 18,
    padding: 5,
    borderTopWidth: 2,
  },
  viewListaTurmas: {
    height: "9%",
    borderBottomWidth: 2,
    justifyContent: "center",
  },
  viewSiglaTopo: {
    width: "70%",
    justifyContent: "center",
    borderBottomWidth: 2,
    borderRightWidth: 2,
  },
  viewOperacaoTopo: {
    width: "30%",
    justifyContent: "center",
    borderBottomWidth: 2,
  },
  txtMedioCentralizado: {
    fontSize: 18,
    textAlign: "center",
  },
  menu: {
    position: "absolute",
    width: "32%",
    height: "100%",
    backgroundColor: "white",
    borderRightWidth: 2,
  },
  cabecalhoMenu: {
    height: "18%",
    backgroundColor: "blue",
    borderBottomWidth: 2,
    alignItems: "center",
    flexDirection: "row",
  },
  menuBotoes: {
    width: "80%",
    borderWidth: 2,
    borderRadius: 20,
    padding: 10,
    alignItems: "center",
    marginBottom: 10,
  },
});

export default GerenciamentoCursos;
