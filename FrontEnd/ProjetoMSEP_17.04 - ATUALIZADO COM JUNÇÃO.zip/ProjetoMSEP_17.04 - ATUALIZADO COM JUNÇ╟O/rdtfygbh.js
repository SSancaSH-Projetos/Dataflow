import React, { useState, useEffect } from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import Icon from 'react-native-vector-icons/FontAwesome';
import axios from 'axios';
import { Button } from '@mui/material'; // Importando o componente Button do Material-UI

const GerenciarCursos = ({ navigation, route }) => {
  const [cursos, setCursos] = useState([]);
  const [curso, setCurso] = useState([]);

  useEffect(() => {
    if (route.params && route.params.cursoAdicionado) {
      const novoCurso = route.params.cursoAdicionado;
      setCursos([...cursos, novoCurso]);
    }
  }, [route.params]);

  useEffect(() => {
    fetchSituacoesDeAprendizagem();
  }, []); // Este useEffect será chamado apenas uma vez, quando o componente for montado

  const fetchSituacoesDeAprendizagem = async () => {
    try {
      const response = await axios.get("http://10.110.12.36:8080/curso"); // Altere a URL conforme necessário
      setCurso(response.data); // Definindo os cursos obtidos da resposta da requisição
    } catch (error) {
      console.error("Erro ao obter cursos:", error);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.fundo}>
        <TouchableOpacity
          style={[styles.voltarButton, styles.tamanhoButtonVoltar]}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.voltarButtonText}>Voltar</Text>
        </TouchableOpacity>
        <Text style={styles.titulo}>Gerenciar Cursos</Text>
      </View>

      <View style={styles.content}>
        {curso.map((situacao) => (
          <View key={situacao.id} style={styles.situacaoContainer}>
            <Text style={styles.situacaoText}>{situacao.curso}</Text>
            <Text style={styles.situacaoText}>{situacao.carga}</Text>
            <Text style={styles.situacaoText}>{situacao.nivel}</Text>
            <View style={styles.iconContainer}>
              <TouchableOpacity
                onPress={() =>
                  navigation.navigate("EditarCurso", { id: situacao.id })
                }
              >
                <View style={styles.iconAlterar}>
                  <Icon name="edit" size={30} color="black" />
                </View>
              </TouchableOpacity>
              <TouchableOpacity
              >
                <View style={styles.iconCancelar}>
                  <Icon name="close" size={30} color="black" />
                </View>
              </TouchableOpacity>
            </View>
          </View>
        ))}
      </View>

      <Button // Substituindo o TouchableOpacity pelo Button do Material-UI
        variant="contained"
        color="primary"
        style={styles.addButton}
        onClick={() => navigation.navigate("AdicionarCurso")}
      >
        Criar Curso
      </Button>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFF",
  },
  fundo: {
    height: 80,
    backgroundColor: "#3A3042",
    alignSelf: "stretch",
  },
  voltarButton: {
    backgroundColor: "white",
    paddingVertical: 20,
    paddingHorizontal: 10,
    borderRadius: 5,
    justifyContent: "center",
    zIndex: 5,
  },
  voltarButtonText: {
    flexDirection: "row",
    color: "#000",
    fontSize: 16,
    fontWeight: "bold",
    textAlign: "center",
  },
  tamanhoButtonVoltar: {
    width: 66,
    height: 35,
    marginTop: 20,
    marginLeft: 40,
  },
  titulo: {
    color: "#fff",
    textAlign: "center",
    fontSize: 32,
    fontWeight: "bold",
    marginTop: -44,
    zIndex: 1,
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  addButton: {
    alignItems: "center",
    position: "absolute",
    bottom: 20,
    alignSelf: "center",
  },
  buttonContent: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    backgroundColor: "#DDD",
  },
  buttonText: {
    color: "black",
    fontSize: 18,
    fontWeight: "bold",
  },
  situacaoContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 20,
  },
  situacaoText: {
    fontSize: 18,
    marginRight: 10,
  },
  iconContainer: {
    flexDirection: "row",
  },
  iconCancelar: {
    backgroundColor: "#FF4C4C",
    padding: 10,
    borderRadius: 15,
    marginRight: 10,
  },
  iconAlterar: {
    backgroundColor: "#DFFF85",
    padding: 10,
    borderRadius: 15,
    marginRight: 10,
  },
});

export default GerenciarCursos;
