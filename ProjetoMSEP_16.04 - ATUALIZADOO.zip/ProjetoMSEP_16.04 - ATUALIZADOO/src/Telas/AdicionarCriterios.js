import React, { useState } from "react";
import axios from "axios"; 
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  TextInput,
} from "react-native";

const CadastroCriterios = ({ navigation, route }) => {
  const [criterios, setCriterios] = useState([]);
  const [descricao, setDescricao] = useState("");
  const [mostrarInput, setMostrarInput] = useState(false);
  const [novoCriterio, setNovoCriterio] = useState("");
  const [criterioSelecionado, setCriterioSelecionado] = useState(null);
  const [criteriosDesejaveis, setCriteriosDesejaveis] = useState({});

  const handleSalvar = () => {
    if (descricao.trim() !== "") {
      setCriterios([...criterios, { descricao, id: Date.now() }]);
      console.log("Critério Salvo:", { descricao });
      setDescricao("");

      // Enviar o critério para a API usando Axios
      axios.post("http://10.110.12.36:8080/valiacaoCriterioCritico", { descricao })
        .then(response => {
          console.log("Resposta da API:", response.data);
          // Lógica adicional após o salvamento na API, se necessário
        })
        .catch(error => {
          console.error("Erro ao salvar na API:", error);
          // Lógica para lidar com erros, se necessário
        });

      setDescricao("");
    }
  };
    
  

  const handleAdicionarNovoCriterio = () => {
    setMostrarInput(true);
  };

  const handleConfirmarNovoCriterio = () => {
    if (novoCriterio.trim() !== "") {
      setCriteriosDesejaveis({
        ...criteriosDesejaveis,
        [criterioSelecionado]: [
          ...(criteriosDesejaveis[criterioSelecionado] || []),
          novoCriterio,
        ],
      });
      console.log("Novo Critério Desejável Adicionado:", {
        descricao: novoCriterio,
      });
      setNovoCriterio("");
      setMostrarInput(false);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.fundo}>
        <Text style={styles.descricao}>Cadastro de Critérios</Text>
        <TouchableOpacity
          style={[styles.VoltarButton, styles.tamanhoButtonVoltar]}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.VoltarButtonText}>Voltar</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.content}>
        <Text style={styles.label}>Descrição:</Text>
        <TextInput
          style={styles.input}
          value={descricao}
          onChangeText={setDescricao}
        />

        <TouchableOpacity style={styles.button} onPress={handleSalvar}>
          <Text style={styles.buttonText}>Salvar</Text>
        </TouchableOpacity>

        <View style={styles.listaCriterios}>
          <Text style={styles.listaCriteriosTitulo}>Critérios Registrados:</Text>
          {criterios.map((criterio) => (
            <View key={criterio.id}>
              <TouchableOpacity
                onPress={() => setCriterioSelecionado(criterio.id)}
              >
                <Text style={styles.criterioItem}>{criterio.descricao}</Text>
              </TouchableOpacity>
              {criterio.id === criterioSelecionado &&
                (mostrarInput ? (
                  <View style={styles.inputNovoCriterioContainer}>
                    <TextInput
                      style={styles.inputNovoCriterio}
                      value={novoCriterio}
                      onChangeText={setNovoCriterio}
                      onBlur={handleConfirmarNovoCriterio}
                      autoFocus={true}
                    />
                  </View>
                ) : (
                  <TouchableOpacity
                    style={styles.buttonAdicionarCriterio}
                    onPress={handleAdicionarNovoCriterio}
                  >
                    <Text style={styles.buttonAdicionarCriterioText}>
                      Adicionar Critério Desejável
                    </Text>
                  </TouchableOpacity>
                ))}
              {criterio.id === criterioSelecionado &&
                criteriosDesejaveis[criterio.id] &&
                criteriosDesejaveis[criterio.id].map((desejavel, index) => (
                  <Text key={index} style={styles.criterioDesejavelItem}>
                    {desejavel}
                  </Text>
                ))}
            </View>
          ))}
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFF",
    paddingTop: 0,
  },
  fundo: {
    height: 120,
    backgroundColor: "#3A3042",
    alignSelf: "stretch",
  },
  VoltarButton: {
    backgroundColor: "white",
    paddingVertical: 20,
    paddingHorizontal: 15,
    borderRadius: 5,
  },
  VoltarButtonText: {
    color: "#000",
    fontSize: 16,
    fontWeight: "bold",
    marginTop: -10,
    justifyContent: "center",
  },
  tamanhoButtonVoltar: {
    width: 70,
    height: 40,
    marginTop: -20,
  },
  descricao: {
    color: "#fff",
    textAlign: "center",
    fontSize: 38,
    fontWeight: "bold",
    marginTop: 20,
  },
  input: {
    height: 40,
    borderColor: "black",
    borderWidth: 0.3,
    paddingHorizontal: 10,
    borderRadius: 5,
    marginBottom: 10,
  },
  label: {
    fontSize: 18,
    marginBottom: 5,
  },
  content: {
    paddingHorizontal: 20,
    marginTop: 20,
  },
  button: {
    backgroundColor: "#3A3042",
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 5,
    marginTop: 10,
  },
  buttonText: {
    color: "#FFF",
    fontSize: 16,
    fontWeight: "bold",
    textAlign: "center",
  },
  listaCriterios: {
    marginTop: 20,
  },
  listaCriteriosTitulo: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 10,
  },
  criterioItem: {
    fontSize: 16,
    marginBottom: 5,
    textDecorationLine: "underline",
    color: "#007bff",
  },
  criterioDesejavelItem: {
    fontSize: 14,
    marginLeft: 20,
  },
  buttonAdicionarCriterio: {
    backgroundColor: "#3A3042",
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 5,
    marginTop: 10,
  },
  buttonAdicionarCriterioText: {
    color: "#FFF",
    fontSize: 16,
    fontWeight: "bold",
    textAlign: "center",
  },
  inputNovoCriterioContainer: {
    marginTop: 10,
    borderColor: "black",
    borderWidth: 0.3,
    borderRadius: 5,
  },
  inputNovoCriterio: {
    height: 40,
    paddingHorizontal: 10,
  },
});

export default CadastroCriterios;